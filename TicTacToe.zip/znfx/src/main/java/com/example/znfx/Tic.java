package com.example.znfx;

public class Tic {
}
